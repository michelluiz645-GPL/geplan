"""
GEPLAN - Sistema Completo
Execute com: python geplan.py
Acesse em:  http://localhost:8000
"""

import json, os, sqlite3, datetime, zipfile, hashlib, subprocess, sys, webbrowser, time
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

# ══════════════════════════════════════════════
# CAMINHOS
# ══════════════════════════════════════════════
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
FRONTEND    = os.path.join(BASE_DIR, "out")          # gerado pelo: npm run build
PASTA       = os.path.join(os.path.expanduser("~"), "Documentos", "Geplan")
PASTA_ALMOX = os.path.join(PASTA, "ALMOXARIFADO")
PASTA_ENG   = os.path.join(PASTA, "ENGENHARIA")
PASTA_BACK  = os.path.join(PASTA, "BACKUPS")
DB_PATH     = os.path.join(PASTA_ALMOX, "geplan.db")

for _p in [PASTA_ALMOX, PASTA_ENG, PASTA_BACK]:
    os.makedirs(_p, exist_ok=True)

# ══════════════════════════════════════════════
# BANCO DE DADOS
# ══════════════════════════════════════════════
def _db_conn():
    conn = sqlite3.connect(DB_PATH, timeout=15, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn

def _db_init():
    conn = _db_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS dados(
            chave TEXT PRIMARY KEY,
            valor TEXT NOT NULL,
            updated TEXT DEFAULT(datetime('now','localtime'))
        );
        CREATE TABLE IF NOT EXISTS obras(
            id TEXT PRIMARY KEY, setor TEXT, nome TEXT,
            descricao TEXT DEFAULT'', responsavel TEXT DEFAULT'',
            data_inicio TEXT DEFAULT'', data_prev TEXT DEFAULT'',
            status TEXT DEFAULT'ATIVA',
            criado_em TEXT DEFAULT(datetime('now','localtime')),
            criado_por TEXT DEFAULT''
        );
        CREATE TABLE IF NOT EXISTS mov_obras(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            obra_id TEXT, tipo TEXT, descricao TEXT DEFAULT'',
            valor REAL DEFAULT 0, data TEXT DEFAULT'',
            usuario TEXT DEFAULT'',
            criado_em TEXT DEFAULT(datetime('now','localtime'))
        );
    """)
    conn.commit()
    conn.close()

_db_init()

def ler(chave):
    try:
        conn = _db_conn()
        row = conn.execute("SELECT valor FROM dados WHERE chave=?", (chave,)).fetchone()
        conn.close()
        if row:
            return json.loads(row[0])
    except:
        pass
    _arqs = {
        "funcionarios": "funcionarios.json", "equipes": "equipes.json",
        "produtos": "produtos.json", "veiculos": "veiculos.json",
        "movimentos": "movimentos.json", "usuarios": "usuarios.json",
        "numeracao": "numeracao.json", "entregas": "entregas_pendentes.json",
        "equipamentos": "equipamentos.json", "combustiveis": "combustiveis.json",
    }
    for pasta in [PASTA_ALMOX, PASTA]:
        if chave in _arqs:
            p = os.path.join(pasta, _arqs[chave])
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    dados = json.load(f)
                gravar(chave, dados)
                return dados
    return {}

def gravar(chave, dados):
    conn = _db_conn()
    conn.execute(
        "INSERT INTO dados(chave,valor,updated) VALUES(?,?,datetime('now','localtime')) "
        "ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor,updated=excluded.updated",
        (chave, json.dumps(dados, ensure_ascii=False))
    )
    conn.commit()
    conn.close()

def hash_senha(s):
    return hashlib.sha256(s.encode()).hexdigest()

def verificar_login(login, senha):
    usuarios = ler("usuarios")
    if not usuarios:
        admin = {"nome": "Administrador", "login": "admin",
                 "nivel": "ADMIN", "senha": hash_senha("admin123")}
        gravar("usuarios", {"admin": admin})
        usuarios = {"admin": admin}
    h = hash_senha(senha)
    for uid, u in usuarios.items():
        if u.get("login", "").lower() == login.lower() and u.get("senha", "") == h:
            return u
    return None

def agora():
    return datetime.datetime.now().strftime("%d/%m/%Y %H:%M")

# ══════════════════════════════════════════════
# FASTAPI
# ══════════════════════════════════════════════
app = FastAPI(title="GEPLAN", version="1.0.0", docs_url="/api/docs")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Modelos ──────────────────────────────────
class LoginRequest(BaseModel):
    usuario: str
    senha: str
    setor: str

# ── Rotas API ────────────────────────────────
@app.get("/api/health")
def health():
    return {"status": "ok", "hora": agora()}


@app.post("/api/login")
def login(dados: LoginRequest):
    if not dados.usuario or not dados.senha:
        raise HTTPException(status_code=400, detail="Preencha usuário e senha")

    usuario_obj = verificar_login(dados.usuario.strip(), dados.senha)
    if not usuario_obj:
        return {"sucesso": False, "mensagem": "Usuário ou senha incorretos"}

    mapa_setor = {
        "almoxarifado": "ALMOXARIFADO",
        "engenharia":   "ENGENHARIA",
        "rh":           "ALMOXARIFADO",
        "operacional":  "ALMOXARIFADO",
        "manutencao":   "ALMOXARIFADO",
    }
    setor_interno = mapa_setor.get(dados.setor.lower(), "ALMOXARIFADO")

    return {
        "sucesso": True,
        "mensagem": f"Bem-vindo, {usuario_obj.get('nome', '')}!",
        "nome":  usuario_obj.get("nome", ""),
        "nivel": usuario_obj.get("nivel", "OPERADOR"),
        "setor": setor_interno,
    }


@app.get("/api/dashboard")
def dashboard():
    produtos = ler("produtos")
    funcs    = ler("funcionarios")
    veiculos = ler("veiculos")
    return {
        "total_produtos": len(produtos),
        "estoque_critico": sum(
            1 for p in produtos.values()
            if float(p.get("estoque_min", 0) or 0) > 0
            and float(p.get("estoque", 0)) <= float(p.get("estoque_min", 0) or 0)
        ),
        "total_funcionarios": sum(
            1 for f in funcs.values()
            if not f.get("demitido") and f.get("status", "ATIVO") == "ATIVO"
        ),
        "total_veiculos": len(veiculos),
    }


@app.get("/api/produtos")
def listar_produtos():
    produtos = ler("produtos")
    return [
        {
            "codigo":      cb,
            "nome":        p.get("nome", ""),
            "categoria":   p.get("categoria", ""),
            "estoque":     float(p.get("estoque", 0)),
            "estoque_min": float(p.get("estoque_min", 0) or 0),
            "unid":        p.get("unid", "UNID"),
            "critico":     float(p.get("estoque", 0)) <= float(p.get("estoque_min", 0) or 0)
                           and float(p.get("estoque_min", 0) or 0) > 0,
        }
        for cb, p in produtos.items()
    ]


@app.get("/api/funcionarios")
def listar_funcionarios():
    funcs = ler("funcionarios")
    return [
        {"id": k, **{kk: vv for kk, vv in v.items() if kk != "senha"}}
        for k, v in funcs.items()
        if not v.get("demitido") and v.get("status", "ATIVO") == "ATIVO"
    ]


# ── Serve o frontend React (pasta out/) ──────
if os.path.exists(FRONTEND):
    # Arquivos estáticos (_next, images, etc)
    app.mount("/_next", StaticFiles(directory=os.path.join(FRONTEND, "_next")), name="next_static")

    @app.get("/images/{file_path:path}")
    def static_images(file_path: str):
        full = os.path.join(FRONTEND, "images", file_path)
        if os.path.exists(full):
            return FileResponse(full)
        raise HTTPException(status_code=404)

    @app.get("/{full_path:path}")
    def serve_frontend(full_path: str):
        # Tenta servir arquivo exato
        target = os.path.join(FRONTEND, full_path)
        if os.path.isfile(target):
            return FileResponse(target)
        # Tenta com .html
        if os.path.isfile(target + ".html"):
            return FileResponse(target + ".html")
        # Fallback para index.html (SPA)
        return FileResponse(os.path.join(FRONTEND, "index.html"))
else:
    @app.get("/")
    def sem_frontend():
        return JSONResponse({
            "aviso": "Frontend não compilado ainda.",
            "instrucao": "Execute: npm run build  (dentro da pasta do projeto v0)",
            "api_docs": "http://localhost:8000/api/docs"
        })


# ══════════════════════════════════════════════
# INICIALIZAÇÃO
# ══════════════════════════════════════════════
if __name__ == "__main__":
    import uvicorn

    frontend_ok = os.path.exists(FRONTEND)

    print("=" * 50)
    print("  GEPLAN - Sistema de Gestão Operacional")
    print("=" * 50)

    if not frontend_ok:
        print("\n⚠️  ATENÇÃO: Frontend não compilado!")
        print("   Faça isso UMA VEZ antes de usar:\n")
        print("   1. Abra um terminal na pasta do projeto v0")
        print("   2. Execute:  npm run build")
        print("   3. Copie a pasta 'out/' para junto deste arquivo")
        print()
    else:
        print(f"\n✅ Frontend encontrado em: {FRONTEND}")

    print(f"🗄️  Banco de dados: {DB_PATH}")
    print(f"\n🚀 Iniciando servidor em http://localhost:8000")
    print(f"📖 API docs em     http://localhost:8000/api/docs")
    print("\nPressione Ctrl+C para encerrar\n")

    # Abre o navegador automaticamente após 1.5s
    if frontend_ok:
        def abrir_browser():
            time.sleep(1.5)
            webbrowser.open("http://localhost:8000")
        import threading
        threading.Thread(target=abrir_browser, daemon=True).start()

    uvicorn.run(app, host="0.0.0.0", port=8000)
