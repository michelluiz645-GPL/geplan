"use client"

import { useState } from "react"
import { Eye, EyeOff, Truck, Building2, Wrench, Package, HardHat, ArrowRight, Users, ClipboardList, Settings, AlertCircle } from "lucide-react"
import { GeplanLogo } from "@/components/geplan-logo"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

// ══════════════════════════════════════════
// URL do backend Python (FastAPI)
// ══════════════════════════════════════════
const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

const setores = [
  { id: "almoxarifado", nome: "Almoxarifado",     icon: Package     },
  { id: "engenharia",   nome: "Engenharia",        icon: HardHat     },
  { id: "rh",           nome: "Recursos Humanos",  icon: Users       },
  { id: "operacional",  nome: "Operacional",        icon: ClipboardList },
  { id: "manutencao",   nome: "Manutencao",         icon: Settings    },
]

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [setor, setSetor]               = useState("almoxarifado")
  const [usuario, setUsuario]           = useState("")
  const [senha, setSenha]               = useState("")
  const [erro, setErro]                 = useState("")
  const [carregando, setCarregando]     = useState(false)

  // ── Chama o backend Python ──────────────────
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setErro("")

    if (!usuario || !senha) {
      setErro("Preencha usuário e senha.")
      return
    }

    setCarregando(true)
    try {
      const res = await fetch(`${API_URL}/api/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ usuario, senha, setor }),
      })

      const data = await res.json()

      if (!res.ok) {
        setErro(data.detail || "Erro ao conectar com o servidor.")
        return
      }

      if (data.sucesso) {
        // Login OK — salva dados e redireciona
        localStorage.setItem("geplan_usuario", JSON.stringify({
          nome:  data.nome,
          nivel: data.nivel,
          setor: data.setor,
        }))
        // Redireciona para o dashboard
        window.location.href = "/dashboard"
      } else {
        setErro(data.mensagem || "Usuário ou senha incorretos.")
      }
    } catch (err) {
      setErro("Não foi possível conectar ao servidor. Verifique se o backend está rodando.")
    } finally {
      setCarregando(false)
    }
  }

  return (
    <div className="min-h-screen flex">
      {/* ── Lado Esquerdo - Imagem + Branding ── */}
      <div className="hidden lg:flex lg:w-1/2 xl:w-3/5 relative">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url('/images/hero-bg.png')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0f1a2e]/90 via-[#0f1a2e]/70 to-[#0f1a2e]/95" />

        <div className="relative z-10 flex flex-col justify-between p-12 xl:p-16">
          <div>
            <GeplanLogo />
            <p className="text-white/60 text-sm tracking-wide mt-3">
              Sistema de Gestão Operacional
            </p>
            <div className="w-12 h-1 bg-[#3b82f6] mt-4" />
          </div>

          <div>
            <div className="w-16 h-1 bg-[#f97316] mb-8" />
            <div className="space-y-5">
              {[
                { icon: Truck,     titulo: "Terraplanagem",           sub: "Movimentacao de terra e nivelamento" },
                { icon: Building2, titulo: "Obras Publicas e Privadas", sub: "Construcao e infraestrutura"       },
                { icon: Wrench,    titulo: "Conservacao",              sub: "Manutencao e reparos"               },
              ].map(({ icon: Icon, titulo, sub }) => (
                <div key={titulo} className="flex items-center gap-4 text-white/90">
                  <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur flex items-center justify-center">
                    <Icon className="h-6 w-6 text-[#f97316]" />
                  </div>
                  <div>
                    <span className="text-base font-semibold block">{titulo}</span>
                    <span className="text-white/50 text-sm">{sub}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <p className="text-white/30 text-xs">
            GEPLAN © 2025 - Todos os direitos reservados
          </p>
        </div>
      </div>

      {/* ── Lado Direito - Formulário ── */}
      <div className="flex-1 lg:w-1/2 xl:w-2/5 bg-[#0f1a2e] flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">

          {/* Logo mobile */}
          <div className="lg:hidden mb-10 text-center flex flex-col items-center">
            <GeplanLogo size="small" />
            <p className="text-white/50 text-sm mt-2">Sistema de Gestão Operacional</p>
            <div className="w-10 h-1 bg-[#3b82f6] mt-3" />
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">Acesso ao Sistema</h2>
            <p className="text-white/50 text-sm">Selecione seu setor e entre com suas credenciais</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">

            {/* Seleção de Setor */}
            <div>
              <Label className="text-xs uppercase tracking-wider text-white/40 mb-3 block">
                Setor
              </Label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {setores.map((s) => {
                  const Icon = s.icon
                  const isSelected = setor === s.id
                  return (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setSetor(s.id)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-xl border transition-all ${
                        isSelected
                          ? "bg-[#f97316]/15 border-[#f97316] shadow-lg shadow-[#f97316]/10"
                          : "bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/10"
                      }`}
                    >
                      <Icon className={`h-5 w-5 ${isSelected ? "text-[#f97316]" : "text-white/40"}`} />
                      <span className={`text-xs font-medium text-center leading-tight ${isSelected ? "text-white" : "text-white/60"}`}>
                        {s.nome}
                      </span>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Usuário */}
            <div>
              <Label htmlFor="usuario" className="text-xs uppercase tracking-wider text-white/40 mb-2 block">
                Usuario
              </Label>
              <Input
                id="usuario"
                type="text"
                placeholder="Digite seu usuario"
                value={usuario}
                onChange={(e) => setUsuario(e.target.value)}
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-[#f97316]/50 focus:ring-[#f97316]/20 h-12"
                disabled={carregando}
              />
            </div>

            {/* Senha */}
            <div>
              <Label htmlFor="senha" className="text-xs uppercase tracking-wider text-white/40 mb-2 block">
                Senha
              </Label>
              <div className="relative">
                <Input
                  id="senha"
                  type={showPassword ? "text" : "password"}
                  placeholder="Digite sua senha"
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-[#f97316]/50 focus:ring-[#f97316]/20 h-12 pr-12"
                  disabled={carregando}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-white/40 hover:text-white transition-colors"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {/* Mensagem de erro */}
            {erro && (
              <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3">
                <AlertCircle className="h-4 w-4 text-red-400 flex-shrink-0" />
                <p className="text-red-400 text-sm">{erro}</p>
              </div>
            )}

            {/* Botão Entrar */}
            <Button
              type="submit"
              disabled={carregando}
              className="w-full bg-[#f97316] hover:bg-[#ea580c] text-white font-semibold h-12 rounded-xl transition-all hover:shadow-lg hover:shadow-[#f97316]/25 disabled:opacity-60"
            >
              {carregando ? "Entrando..." : "Entrar"}
              {!carregando && <ArrowRight className="ml-2 h-5 w-5" />}
            </Button>

            {/* Esqueceu a senha */}
            <div className="text-center">
              <button type="button" className="text-white/40 hover:text-[#f97316] text-sm transition-colors">
                Esqueceu sua senha?
              </button>
            </div>

          </form>

          <p className="lg:hidden text-white/30 text-xs mt-10 text-center">GEPLAN © 2025</p>
        </div>
      </div>
    </div>
  )
}
