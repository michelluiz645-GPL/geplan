/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',      // gera HTML/CSS/JS estático na pasta "out/"
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
}

export default nextConfig
