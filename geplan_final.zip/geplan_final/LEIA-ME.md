# GEPLAN - Como usar

## Primeira vez (só precisa fazer uma vez)

```
1. Instale as dependências Python:
   pip install fastapi uvicorn

2. Instale e compile o frontend:
   npm install
   npm run build

3. Pronto! Agora é só usar o passo abaixo.
```

## Rodar o sistema

```
python geplan.py
```

O navegador abre automaticamente em http://localhost:8000

---

Login padrão: admin / admin123
