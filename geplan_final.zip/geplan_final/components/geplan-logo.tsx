"use client"

export function GeplanLogo({ className = "", size = "default" }: { className?: string; size?: "default" | "small" }) {
  const isSmall = size === "small"
  
  return (
    <div className={`flex items-center gap-1 ${className}`}>
      {/* Ícone da concha/terra */}
      <svg 
        viewBox="0 0 40 40" 
        className={isSmall ? "w-8 h-8" : "w-10 h-10 xl:w-12 xl:h-12"}
        fill="none"
      >
        {/* Forma da concha/movimento de terra */}
        <path
          d="M8 28C8 28 12 20 20 20C28 20 32 28 32 28"
          stroke="#f97316"
          strokeWidth="4"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M4 32C4 32 10 22 20 22C30 22 36 32 36 32"
          stroke="#f97316"
          strokeWidth="3"
          strokeLinecap="round"
          fill="none"
          opacity="0.6"
        />
        <circle cx="20" cy="12" r="6" fill="#f97316" />
      </svg>
      
      {/* Texto do Logo */}
      <div className="flex items-baseline">
        <span 
          className={`font-black tracking-tight ${isSmall ? "text-3xl" : "text-4xl xl:text-5xl"}`}
          style={{ color: "#f97316" }}
        >
          GE
        </span>
        <span 
          className={`font-black tracking-tight text-white ${isSmall ? "text-3xl" : "text-4xl xl:text-5xl"}`}
        >
          PLAN
        </span>
      </div>
    </div>
  )
}
